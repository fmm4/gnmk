// ConsoleApplication1.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <string>
#include <ctime>	
using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	clock_t start;
	double duration;
	int reads = 0;

	start = clock();
	
	ifstream inputtxt;
	ofstream outputtxt;
	string current_read;
	string previous_read;
	string final_chromossome;


	inputtxt.open("input.txt");
	if (!inputtxt.is_open()) {

		cout << "Could not find Read file 'input.txt' in the folder the executible is located.\n";
		cout << "Please check if they are in the same folder and try again.\n";

	}else{
		final_chromossome.reserve(10000);

		unsigned int curr_read_size;
		unsigned int curr_read_half;
		unsigned int final_position = -1;
		size_t temp;
		size_t stop = (unsigned int) -1;

		while (!inputtxt.eof()) {

			inputtxt >> current_read;
			final_position = -1;

			if (!final_chromossome.empty()){

				//No exemplo se usa strings menores que metade do read (no caso, o primeiro exemplo usa 4 ao invez de 5, que e metade)
				curr_read_size = current_read.size();
				curr_read_half = 4;

				previous_read = final_chromossome.substr(final_chromossome.size() - curr_read_size);

				for (unsigned int i = curr_read_half; i < curr_read_size; i++)
				{
					temp = current_read.find(
						previous_read.substr(previous_read.size()-i)
						);
						
					if (temp == stop){
						i = curr_read_size+1;
					}
					else{
						//pos+offset
						final_position = temp + i;
					}
				}	

				if (final_position != stop){
					final_chromossome += current_read.substr(final_position);
				}
			}			
			else{
				final_chromossome += current_read;
			}

			reads++;
		}
			
		inputtxt.close();

		outputtxt.open("output.txt");
		outputtxt << final_chromossome;
		outputtxt.close();
	}

	duration = (clock() - start) / (double) CLOCKS_PER_SEC;
	cout << "Reads analyzed: " << reads << "\n";
	cout << "Time taken : " << duration << "s \n";
	cout << "(Press ENTER to leave)";
	getchar();

	return 0;
}

